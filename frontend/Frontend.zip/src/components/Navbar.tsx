// import { useEffect, useState } from "react";
// import { Menu, X } from "lucide-react";
// import logo from "../assets/Logo1.png";

// export default function Navbar() {
//   const [mobileOpen, setMobileOpen] = useState(false);

//   // Close on ESC, unlock scroll on unmount
//   useEffect(() => {
//     const onKey = (e: KeyboardEvent) => {
//       if (e.key === "Escape") setMobileOpen(false);
//     };
//     window.addEventListener("keydown", onKey);

//     // Lock body scroll when menu open (mobile)
//     if (mobileOpen) {
//       const prev = document.body.style.overflow;
//       document.body.style.overflow = "hidden";
//       return () => {
//         document.body.style.overflow = prev;
//         window.removeEventListener("keydown", onKey);
//       };
//     }
//     return () => window.removeEventListener("keydown", onKey);
//   }, [mobileOpen]);

//   // Close menu when resizing up to desktop
//   useEffect(() => {
//     const onResize = () => {
//       if (window.innerWidth >= 768 && mobileOpen) setMobileOpen(false);
//     };
//     window.addEventListener("resize", onResize);
//     return () => window.removeEventListener("resize", onResize);
//   }, [mobileOpen]);

//   const closeMobile = () => setMobileOpen(false);

//   return (
//     <header className="sticky top-0 z-50 bg-white/80 backdrop-blur border-b border-slate-100">
//       <div className="mx-auto w-auto max-w-screen-xl  h-14 flex items-center justify-between">
//         {/* Brand */}
//         <a href="/" className="inline-flex items-center gap-2" aria-label="GenIntel Home">
//           <img
//             src={logo}
//             alt="GenIntel Logo"
//             className="h-20 w-auto sm:h-10 object-contain"
//           />
//           {/* If you want text next to logo: */}
//           <span className="hidden sm:inline font-semibold text-slate-900">Sales Advisor</span>
//         </a>

//         {/* Desktop nav */}
//         <nav className="hidden md:flex items-center gap-6 text-sm text-slate-600">
//           <a className="hover:text-slate-900" href="#features">Features</a>
//           {/* <a className="hover:text-slate-900" href="#pricing">Pricing</a>
//           <a className="hover:text-slate-900" href="#integrations">Integrations</a> */}
//           <a className="hover:text-slate-900" href="#docs">Docs</a>
//         </nav>

//         {/* CTA (desktop) */}
//         <a
//           href="#voice"
//           className="hidden md:inline-block rounded-full bg-indigo-600 text-white text-sm font-semibold px-4 py-2 shadow hover:bg-indigo-700"
//         >
//           Try Voice Chat
//         </a>

//         {/* Mobile hamburger */}
//         <button
//           onClick={() => setMobileOpen((v) => !v)}
//           className="md:hidden rounded-lg p-2 text-slate-600 hover:bg-slate-100"
//           aria-label="Toggle menu"
//           aria-expanded={mobileOpen}
//           aria-controls="mobile-menu"
//         >
//           {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
//         </button>
//       </div>

//       {/* Mobile sheet */}
//       <div
//         id="mobile-menu"
//         className={`md:hidden ${mobileOpen ? "block" : "hidden"}`}
//       >
//         {/* Backdrop */}
//         <div
//           className="fixed inset-0 bg-black/20"
//           onClick={closeMobile}
//           aria-hidden="true"
//         />

//         {/* Panel */}
//         <div className="
//           fixed left-0 right-0 top-0
//           pt-[env(safe-area-inset-top)]
//           bg-white border-b border-slate-200
//           px-4 py-3 space-y-2 text-sm text-slate-700
//           motion-reduce:transition-none
//           transition-transform duration-200 ease-out
//         ">
//           <div className="flex items-center justify-between h-10">
//             <span className="font-semibold text-slate-900">Menu</span>
//             <button
//               onClick={closeMobile}
//               className="rounded-lg p-2 text-slate-600 hover:bg-slate-100"
//               aria-label="Close menu"
//             >
//               <X className="h-5 w-5" />
//             </button>
//           </div>

//           <nav className="grid gap-2">
//             <a href="#features" onClick={closeMobile} className="block hover:text-slate-900">Features</a>
//             <a href="#pricing" onClick={closeMobile} className="block hover:text-slate-900">Pricing</a>
//             <a href="#integrations" onClick={closeMobile} className="block hover:text-slate-900">Integrations</a>
//             <a href="#docs" onClick={closeMobile} className="block hover:text-slate-900">Docs</a>
//             <a
//               href="#voice"
//               onClick={closeMobile}
//               className="mt-2 block w-full rounded-full bg-indigo-600 text-white text-center px-4 py-2 font-semibold shadow hover:bg-indigo-700"
//             >
//               Try Voice Chat
//             </a>
//           </nav>

//           <div className="pb-[env(safe-area-inset-bottom)]" />
//         </div>
//       </div>
//     </header>
//   );
// }



// frontend/src/components/Navbar.tsx
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import logo from "../assets/Logo2.png"; // Assuming this is your logo path

/**
 * Custom hook to manage mobile menu state and side effects.
 * This encapsulates logic for keyboard events, scroll locking, and resizing.
 */
const useMobileMenu = () => {
    const [isOpen, setIsOpen] = useState(false);

    useEffect(() => {
        if (!isOpen) return;

        // Lock body scroll when menu is open
        const originalOverflow = document.body.style.overflow;
        document.body.style.overflow = "hidden";

        // Close menu on ESC key
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === "Escape") {
                setIsOpen(false);
            }
        };

        // Close menu if window is resized to desktop width
        const handleResize = () => {
            if (window.innerWidth >= 768) {
                setIsOpen(false);
            }
        };

        window.addEventListener("keydown", handleKeyDown);
        window.addEventListener("resize", handleResize);

        // Cleanup function
        return () => {
            document.body.style.overflow = originalOverflow;
            window.removeEventListener("keydown", handleKeyDown);
            window.removeEventListener("resize", handleResize);
        };
    }, [isOpen]);

    return { isOpen, setIsOpen };
};

export default function Navbar() {
    const { isOpen, setIsOpen } = useMobileMenu();
    const closeMobileMenu = () => setIsOpen(false);

    return (
        <header className="sticky top-0 z-50 bg-[#1A1E2E]/80 backdrop-blur-sm border-b border-slate-700/50 shadow-lg">
            <div className="mx-auto w-full max-w-screen-xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
                {/* Brand Logo and Name */}
                <a href="/" className="inline-flex items-center gap-3" aria-label="GenIntel Home">
                    <img
                       src={logo}
                    alt="GenIntel Logo"
            className="h-20 w-auto sm:h-10 object-contain" // Corrected logo sizing
                    />
                    <span className="bg-gradient-to-r from-teal-300 via-cyan-400 to-blue-500 bg-clip-text text-transparent font-semibold text-xl">
                        Sales Advisor
                    </span>
                </a>

                {/* Desktop Navigation */}
                <nav className="hidden md:flex items-center gap-8 text-base text-slate-300">
                    <a className="hover:text-white transition-colors" href="#features">Features</a>
                    <a className="hover:text-white transition-colors" href="#docs">Docs</a>
                </nav>

                {/* CTA Button (Desktop) */}
                <a
                    href="#voice"
                    className="hidden md:inline-block rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-semibold px-5 py-2.5 shadow-md hover:opacity-90 transition-opacity"
                >
                    Try Voice Chat
                </a>

                {/* Mobile Menu Toggle */}
                <button
                    onClick={() => setIsOpen((prev) => !prev)}
                    className="md:hidden rounded-lg p-2 text-slate-300 hover:bg-slate-800 transition-colors"
                    aria-label="Toggle menu"
                    aria-expanded={isOpen}
                    aria-controls="mobile-menu"
                >
                    {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                </button>
            </div>

            {/* Mobile Menu Panel */}
            <div
                id="mobile-menu"
                className={`md:hidden absolute top-full left-0 right-0 transition-transform duration-300 ease-in-out ${isOpen ? "translate-y-0" : "-translate-y-[120%]"
                    }`}
            >
                {/* Backdrop */}
                <div
                    className={`fixed inset-0 bg-black/30 backdrop-blur-sm ${isOpen ? "block" : "hidden"}`}
                    onClick={closeMobileMenu}
                    aria-hidden="true"
                />

                {/* Menu Content */}
                <div className="relative bg-[#2A3048] border-b border-slate-700 p-4 space-y-4">
                    <nav className="grid gap-3 text-slate-200">
                        <a href="#features" onClick={closeMobileMenu} className="block p-2 rounded-md hover:bg-slate-700">Features</a>
                        <a href="#docs" onClick={closeMobileMenu} className="block p-2 rounded-md hover:bg-slate-700">Docs</a>
                        <a
                            href="#voice"
                            onClick={closeMobileMenu}
                            className="mt-2 block w-full rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-center px-4 py-2.5 font-semibold shadow hover:opacity-90"
                        >
                            Try Voice Chat
                        </a>
                    </nav>
                </div>
            </div>
        </header>
    );
}