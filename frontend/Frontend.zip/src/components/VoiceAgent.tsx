// /// frontend/src/components/VoiceAgent.tsx
// import { useCallback, useEffect, useMemo, useRef, useState } from "react";
// import Vapi from "@vapi-ai/web";

// import agentSpeakingGif from "../assets/VoiceOver.gif";
// import userSpeakingGif from "../assets/original-VoiceEffect.gif";
// import agentImage from "../assets/BookMyService_agent.jpg";

// const CLIENT_KEY = import.meta.env.VITE_VAPI_CLIENT_KEY as string;
// const AGENT_ID = import.meta.env.VITE_VAPI_AGENT_ID as string;
// // --- Removed ---: CONVERSATION_STORAGE_KEY is no longer needed.
// const vapi = new Vapi(CLIENT_KEY);

// type Speaker = "user" | "agent" | null;
// type Message = {
//     role: "user" | "assistant";
//     transcript: string;
// };

// const UserIcon = (props: React.SVGProps<SVGSVGElement>) => (
//     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
//         <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
//     </svg>
// );


// export default function VoiceAgent() {
//     const [isCallActive, setIsCallActive] = useState(false);
//     const [whoIsSpeaking, setWhoIsSpeaking] = useState<Speaker>(null);
//     const [status, setStatus] = useState<"idle" | "connecting" | "in-call" | "stopping">("idle");
//     const [error, setError] = useState<string | null>(null);

//     // --- Modified ---: Initialize conversation state as an empty array.
//     const [conversation, setConversation] = useState<Message[]>([]);

//     const conversationRef = useRef<HTMLDivElement>(null);
//     const startingRef = useRef(false);
//     const stoppingRef = useRef(false);
//     const mountedRef = useRef(true);

//     useEffect(() => {
//         mountedRef.current = true;
//         const v: any = vapi;

//         const onSpeechStart = (p?: any) => {
//             const s = typeof p === "string" ? p : p?.speaker;
//             if (s === "user") setWhoIsSpeaking("user");
//             if (s === "agent") setWhoIsSpeaking("agent");
//         };
//         const onSpeechStop = () => setWhoIsSpeaking(null);
//         const onCallStart = () => {
//             setIsCallActive(true);
//             setStatus("in-call");
//             setError(null);
//             // --- New ---: Clear conversation at the start of a new call
//             setConversation([]);
//         };
//         const onCallEnd = () => {
//             setIsCallActive(false);
//             setStatus("idle");
//             setWhoIsSpeaking(null);
//             startingRef.current = false;
//             stoppingRef.current = false;
//         };
//         const onError = (e: any) => {
//             const msg =
//                 e?.message?.includes("Permission denied") ||
//                 e?.name === "NotAllowedError"
//                     ? "Microphone access denied. Please allow mic permissions."
//                     : e?.message || String(e);
//             setError(msg);
//             setStatus("idle");
//             setIsCallActive(false);
//             startingRef.current = false;
//             stoppingRef.current = false;
//         };

//         const onMessage = (message: any) => {
//             if (message.type === "transcript" && message.transcript) {
//                 setConversation((prev) => {
//                     const lastMessage = prev[prev.length - 1];
//                     if (lastMessage && lastMessage.role === message.role) {
//                         const updatedConversation = [...prev];
//                         updatedConversation[prev.length - 1] = {
//                             ...lastMessage,
//                             transcript: message.transcript,
//                         };
//                         return updatedConversation;
//                     }
//                     return [...prev, { role: message.role, transcript: message.transcript }];
//                 });
//             }
//         };

//         v.on?.("speech-start", onSpeechStart);
//         v.on?.("speech-stop", onSpeechStop);
//         v.on?.("call-start", onCallStart);
//         v.on?.("call-end", onCallEnd);
//         v.on?.("error", onError);
//         v.on?.("message", onMessage);

//         v.on?.("agent-speech-start", onSpeechStart);
//         v.on?.("agent-speech-stop", onSpeechStop);
//         v.on?.("user-speech-start", () => onSpeechStart("user"));
//         v.on?.("user-speech-stop", onSpeechStop);

//         return () => {
//             mountedRef.current = false;
//             v.off?.("speech-start", onSpeechStart);
//             v.off?.("speech-stop", onSpeechStop);
//             v.off?.("call-start", onCallStart);
//             v.off?.("call-end", onCallEnd);
//             v.off?.("error", onError);
//             v.off?.("message", onMessage);
//             v.off?.("agent-speech-start", onSpeechStart);
//             v.off?.("agent-speech-stop", onSpeechStop);
//             v.off?.("user-speech-start", () => onSpeechStart("user"));
//             v.off?.("user-speech-stop", onSpeechStop);
//         };
//     }, []);

//     // --- Modified ---: Removed the localStorage saving logic.
//     useEffect(() => {
//         if (conversationRef.current) {
//             conversationRef.current.scrollTop = conversationRef.current.scrollHeight;
//         }
//     }, [conversation]);


//     const secureContext =
//         typeof window !== "undefined" && (window.isSecureContext || location.hostname === "localhost");

//     const startCall = useCallback(async () => {
//         if (startingRef.current || isCallActive || status === "connecting") return;
//         setError(null);
//         if (!CLIENT_KEY || !AGENT_ID) {
//             setError("Missing env: VITE_VAPI_CLIENT_KEY or VITE_VAPI_AGENT_ID");
//             return;
//         }
//         if (!secureContext) {
//             setError("Use HTTPS (or localhost) for microphone access.");
//             return;
//         }
//         try {
//             startingRef.current = true;
//             setStatus("connecting");
//             await navigator.mediaDevices.getUserMedia({ audio: true });
//             await vapi.start(AGENT_ID);
//         } catch (e: any) {
//             setError(e?.message || String(e));
//             setStatus("idle");
//             startingRef.current = false;
//         }
//     }, [isCallActive, status, secureContext]);

//     const stopCall = useCallback(async () => {
//         if (stoppingRef.current || !isCallActive) return;
//         stoppingRef.current = true;
//         setStatus("stopping");
//         setIsCallActive(false);
//         setWhoIsSpeaking(null);
//         const stopPromise = Promise.resolve().then(() => (vapi as any).stop?.());
//         const timeout = new Promise<void>((resolve) => setTimeout(resolve, 600));
//         try {
//             await Promise.race([stopPromise, timeout]);
//         } finally {
//             try {
//                 const anyV: any = vapi as any;
//                 anyV.stream?.getTracks?.().forEach((t: MediaStreamTrack) => t.stop());
//                 anyV.pc?.getSenders?.().forEach((s: RTCRtpSender) => s?.track?.stop?.());
//                 anyV.pc?.getReceivers?.forEach?.((r: RTCRtpReceiver) => r?.track?.stop?.());
//                 anyV.pc?.close?.();
//             } catch { }
//             if (mountedRef.current) setStatus("idle");
//             stoppingRef.current = false;
//             startingRef.current = false;
//         }
//     }, [isCallActive]);


//     const avatarSrc = useMemo(() => {
//         if (whoIsSpeaking === "user") return userSpeakingGif;
//         if (whoIsSpeaking === "agent") return agentSpeakingGif;
//         return agentImage;
//     }, [whoIsSpeaking]);

//     const badge = {
//         idle: { text: "Idle", color: "bg-slate-200 text-slate-700" },
//         connecting: { text: "Connecting…", color: "bg-amber-100 text-amber-700" },
//         "in-call": { text: "Live", color: "bg-emerald-100 text-emerald-700" },
//         stopping: { text: "Disconnecting…", color: "bg-rose-100 text-rose-700" },
//     }[status];

//     return (
//         <section className="mx-auto max-w-6xl px-4 pt-3 pb-[calc(2.5rem+env(safe-area-inset-bottom))]">
//             {error && (
//                 <div className="mb-3 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800">
//                     {error}
//                 </div>
//             )}

//             <div className="flex flex-col lg:flex-row lg:items-start lg:gap-8">
//                 {/* Left Column: Agent Avatar and Controls */}
//                 <div className="flex w-full lg:w-auto flex-col items-center lg:flex-shrink-0">
//                     <div className="relative mt-4 flex justify-center">
//                         <div className="relative w-40 h-40 sm:w-56 sm:h-56">
//                             {status === "in-call" && (
//                                 <div className="absolute inset-0 rounded-full animate-ping bg-indigo-300/30" />
//                             )}
//                             <img
//                                 src={avatarSrc}
//                                 alt="Speaking state"
//                                 className="relative z-10 w-full h-full object-cover rounded-full shadow-2xl border-4 border-white/80 dark:border-slate-700/50"
//                             />
//                         </div>
//                     </div>

//                     <div className="mt-3 text-center">
//                         <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${badge.color}`}>
//                             {badge.text}
//                         </span>
//                         {whoIsSpeaking === "user" && <span className="ml-2 text-fuchsia-700 dark:text-fuchsia-400 text-xs">Listening…</span>}
//                         {whoIsSpeaking === "agent" && <span className="ml-2 text-indigo-700 dark:text-indigo-400 text-xs">Rohan is speaking…</span>}
//                     </div>

//                     <div className="mt-4 flex justify-center">
//                         {status === "idle" || status === "connecting" ? (
//                             <button
//                                 onClick={startCall}
//                                 disabled={status === "connecting"}
//                                 className="rounded-xl bg-indigo-600 px-6 py-3 text-white font-semibold shadow hover:bg-indigo-700 active:scale-[0.98] disabled:opacity-60 transition-all"
//                             >
//                                 {status === "connecting" ? "Connecting…" : "Let’s Get Started"}
//                             </button>
//                         ) : (
//                             <button
//                                 onClick={stopCall}
//                                 disabled={status === "stopping"}
//                                 aria-busy={status === "stopping" ? "true" : "false"}
//                                 className={`rounded-xl px-6 py-3 text-white font-semibold shadow active:scale-[0.98] disabled:opacity-60 transition-all ${status === "stopping" ? "bg-rose-400 cursor-not-allowed" : "bg-rose-500 hover:bg-rose-600"}`}
//                                 title={status === "stopping" ? "Disconnecting…" : "End Call"}
//                             >
//                                 {status === "stopping" ? "Disconnecting…" : "End Call"}
//                             </button>
//                         )}
//                     </div>
//                 </div>

//                 {/* Right Column: Conversation Display */}
//                 <div
//                     ref={conversationRef}
//                     className="mt-6 lg:mt-0 w-full h-96 overflow-y-auto p-6 space-y-6 rounded-2xl bg-white/30 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 backdrop-blur-sm"
//                 >
//                     {conversation.length === 0 ? (
//                         <div className="flex items-center justify-center h-full text-slate-500 dark:text-slate-400">
//                             Your conversation will appear here.
//                         </div>
//                     ) : (
//                         conversation.map((msg, index) => {
//                             const isUser = msg.role === 'user';
//                             return (
//                                 <div key={index} className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
//                                     {!isUser && (
//                                         <img src={agentImage} className="w-8 h-8 rounded-full object-cover flex-shrink-0" alt="Agent" />
//                                     )}
//                                     <div className={`flex flex-col gap-1 ${isUser ? 'items-end' : 'items-start'}`}>
//                                         <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
//                                             {isUser ? 'You' : 'Rohan'}
//                                         </span>
//                                         <div
//                                             className={`px-4 py-2.5 rounded-2xl max-w-xs md:max-w-md text-sm leading-relaxed
//                                             ${isUser
//                                                     ? 'bg-gradient-to-r from-indigo-600 to-blue-500 text-white rounded-br-none'
//                                                     : 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-bl-none'
//                                                 }`}
//                                         >
//                                             {msg.transcript}
//                                         </div>
//                                     </div>
//                                     {isUser && (
//                                         <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-600 flex items-center justify-center flex-shrink-0">
//                                             <UserIcon className="w-5 h-5 text-slate-500 dark:text-slate-300" />
//                                         </div>
//                                     )}
//                                 </div>
//                             );
//                         })
//                     )}
//                 </div>
//             </div>
//         </section>
//     );
// }






// frontend/src/components/VoiceAgent.tsx
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Vapi from "@vapi-ai/web";

import agentSpeakingGif from "../assets/VoiceOver.gif";
import userSpeakingGif from "../assets/original-VoiceEffect.gif";
import agentImage from "../assets/BookMyService_agent.jpg";

const CLIENT_KEY = import.meta.env.VITE_VAPI_CLIENT_KEY as string;
const AGENT_ID = import.meta.env.VITE_VAPI_AGENT_ID as string;
const vapi = new Vapi(CLIENT_KEY);

type Speaker = "user" | "agent" | null;
type Message = {
    role: "user" | "assistant";
    transcript: string;
};

const UserIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
    </svg>
);

export default function VoiceAgent() {
    const [isCallActive, setIsCallActive] = useState(false);
    const [whoIsSpeaking, setWhoIsSpeaking] = useState<Speaker>(null);
    const [status, setStatus] = useState<"idle" | "connecting" | "in-call" | "stopping">("idle");
    const [error, setError] = useState<string | null>(null);
    const [conversation, setConversation] = useState<Message[]>([]);
    const conversationRef = useRef<HTMLDivElement>(null);
    const startingRef = useRef(false);
    const stoppingRef = useRef(false);
    const mountedRef = useRef(true);

    useEffect(() => {
        mountedRef.current = true;
        const v: any = vapi;
        const onSpeechStart = (p?: any) => {
            const s = typeof p === "string" ? p : p?.speaker;
            if (s === "user") setWhoIsSpeaking("user");
            if (s === "agent") setWhoIsSpeaking("agent");
        };
        const onSpeechStop = () => setWhoIsSpeaking(null);
        const onCallStart = () => {
            setIsCallActive(true);
            setStatus("in-call");
            setError(null);
            setConversation([]);
        };
        const onCallEnd = () => {
            setIsCallActive(false);
            setStatus("idle");
            setWhoIsSpeaking(null);
            startingRef.current = false;
            stoppingRef.current = false;
        };
        const onError = (e: any) => {
            const msg =
                e?.message?.includes("Permission denied") ||
                e?.name === "NotAllowedError"
                    ? "Microphone access denied. Please allow mic permissions."
                    : e?.message || String(e);
            setError(msg);
            setStatus("idle");
            setIsCallActive(false);
            startingRef.current = false;
            stoppingRef.current = false;
        };
        const onMessage = (message: any) => {
            if (message.type === "transcript" && message.transcript) {
                setConversation((prev) => {
                    const lastMessage = prev[prev.length - 1];
                    if (lastMessage && lastMessage.role === message.role) {
                        const updatedConversation = [...prev];
                        updatedConversation[prev.length - 1] = { ...lastMessage, transcript: message.transcript, };
                        return updatedConversation;
                    }
                    return [...prev, { role: message.role, transcript: message.transcript }];
                });
            }
        };
        v.on?.("speech-start", onSpeechStart);
        v.on?.("speech-stop", onSpeechStop);
        v.on?.("call-start", onCallStart);
        v.on?.("call-end", onCallEnd);
        v.on?.("error", onError);
        v.on?.("message", onMessage);
        v.on?.("agent-speech-start", onSpeechStart);
        v.on?.("agent-speech-stop", onSpeechStop);
        v.on?.("user-speech-start", () => onSpeechStart("user"));
        v.on?.("user-speech-stop", onSpeechStop);
        return () => {
            mountedRef.current = false;
            v.off?.("speech-start", onSpeechStart);
            v.off?.("speech-stop", onSpeechStop);
            v.off?.("call-start", onCallStart);
            v.off?.("call-end", onCallEnd);
            v.off?.("error", onError);
            v.off?.("message", onMessage);
            v.off?.("agent-speech-start", onSpeechStart);
            v.off?.("agent-speech-stop", onSpeechStop);
            v.off?.("user-speech-start", () => onSpeechStart("user"));
            v.off?.("user-speech-stop", onSpeechStop);
        };
    }, []);
    useEffect(() => {
        if (conversationRef.current) {
            conversationRef.current.scrollTop = conversationRef.current.scrollHeight;
        }
    }, [conversation]);
    const secureContext = typeof window !== "undefined" && (window.isSecureContext || location.hostname === "localhost");
    const startCall = useCallback(async () => {
        if (startingRef.current || isCallActive || status === "connecting") return;
        setError(null);
        if (!CLIENT_KEY || !AGENT_ID) {
            setError("Missing env: VITE_VAPI_CLIENT_KEY or VITE_VAPI_AGENT_ID");
            return;
        }
        if (!secureContext) {
            setError("Use HTTPS (or localhost) for microphone access.");
            return;
        }
        try {
            startingRef.current = true;
            setStatus("connecting");
            await navigator.mediaDevices.getUserMedia({ audio: true });
            await vapi.start(AGENT_ID);
        } catch (e: any) {
            setError(e?.message || String(e));
            setStatus("idle");
            startingRef.current = false;
        }
    }, [isCallActive, status, secureContext]);
    const stopCall = useCallback(async () => {
        if (stoppingRef.current || !isCallActive) return;
        stoppingRef.current = true;
        setStatus("stopping");
        setIsCallActive(false);
        setWhoIsSpeaking(null);
        const stopPromise = Promise.resolve().then(() => (vapi as any).stop?.());
        const timeout = new Promise<void>((resolve) => setTimeout(resolve, 600));
        try {
            await Promise.race([stopPromise, timeout]);
        } finally {
            try {
                const anyV: any = vapi as any;
                anyV.stream?.getTracks?.().forEach((t: MediaStreamTrack) => t.stop());
                anyV.pc?.getSenders?.().forEach((s: RTCRtpSender) => s?.track?.stop?.());
                anyV.pc?.getReceivers?.forEach?.((r: RTCRtpReceiver) => r?.track?.stop?.());
                anyV.pc?.close?.();
            } catch { }
            if (mountedRef.current) setStatus("idle");
            stoppingRef.current = false;
            startingRef.current = false;
        }
    }, [isCallActive]);
    const avatarSrc = useMemo(() => {
        if (whoIsSpeaking === "user") return userSpeakingGif;
        if (whoIsSpeaking === "agent") return agentSpeakingGif;
        return agentImage;
    }, [whoIsSpeaking]);
    const badge = {
        idle: { text: "Idle", color: "bg-slate-700 text-slate-300" },
        connecting: { text: "Connecting…", color: "bg-amber-600 text-white" },
        "in-call": { text: "Live", color: "bg-green-600 text-white" },
        stopping: { text: "Disconnecting…", color: "bg-rose-600 text-white" },
    }[status];

    return (
        <section className="w-full flex flex-col lg:flex-row items-center justify-center lg:items-start lg:justify-center gap-8 px-4 py-8 max-w-5xl mx-auto">
            {error && (
                <div className="mb-3 rounded-xl border border-rose-400 bg-rose-900/50 px-4 py-3 text-sm text-rose-200 w-full lg:absolute lg:top-24 lg:left-1/2 lg:-translate-x-1/2 lg:max-w-md">
                    {error}
                </div>
            )}

            {/* Left Column: Agent Avatar and Controls */}
            <div className="flex flex-col items-center flex-shrink-0">
                <div className="relative mt-4 flex justify-center">
                    <div className="relative w-48 h-48 sm:w-64 sm:h-64">
                        {status === "in-call" && (
                            <div className="absolute inset-0 rounded-full animate-ping bg-blue-500/50" />
                        )}
                        <img
                            src={avatarSrc}
                            alt="Sales Advisor"
                            className="relative z-10 w-full h-full object-cover rounded-full shadow-2xl border-4 border-slate-700"
                        />
                    </div>
                </div>

                <div className="mt-4 text-center">
                    <span className={`inline-flex items-center rounded-full px-4 py-2 text-sm font-medium ${badge.color}`}>
                        {badge.text}
                    </span>
                    {whoIsSpeaking === "user" && <span className="ml-2 text-fuchsia-400 text-sm">Listening…</span>}
                    {whoIsSpeaking === "agent" && <span className="ml-2 text-indigo-400 text-sm">Rohan is speaking…</span>}
                </div>

                <div className="mt-8 flex justify-center">
                    {status === "idle" || status === "connecting" ? (
                        <button
                            onClick={startCall}
                            disabled={status === "connecting"}
                            className="rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold py-4 px-12 text-lg shadow-lg transition-all duration-300 active:scale-[0.98] disabled:opacity-60"
                        >
                            {status === "connecting" ? "Connecting…" : "Let’s Get Started"}
                        </button>
                    ) : (
                        <button
                            onClick={stopCall}
                            disabled={status === "stopping"}
                            aria-busy={status === "stopping" ? "true" : "false"}
                            className={`rounded-xl py-4 px-12 text-white font-semibold text-lg shadow-lg active:scale-[0.98] disabled:opacity-60 transition-all duration-300 ${status === "stopping" ? "bg-rose-700/80 cursor-not-allowed" : "bg-rose-600 hover:bg-rose-700"}`}
                            title={status === "stopping" ? "Disconnecting…" : "End Chat"}
                        >
                            {status === "stopping" ? "Disconnecting…" : "End Chat"}
                        </button>
                    )}
                </div>
            </div>

            {/* Right Column: Conversation Display */}
            <div
                ref={conversationRef}
                className="mt-8 lg:mt-4 w-full lg:w-96 h-96 lg:h-[450px] overflow-y-auto p-6 space-y-6 rounded-2xl bg-slate-800/70 border border-slate-700 shadow-xl flex flex-col flex-shrink-0"
            >
                {conversation.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-slate-400 text-lg">
                        Your conversation will appear here.
                    </div>
                ) : (
                    conversation.map((msg, index) => {
                        const isUser = msg.role === 'user';
                        return (
                            <div key={index} className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
                                {!isUser && (
                                    <img src={agentImage} className="w-8 h-8 rounded-full object-cover flex-shrink-0 border border-slate-600" alt="Agent" />
                                )}
                                <div className={`flex flex-col gap-1 ${isUser ? 'items-end' : 'items-start'}`}>
                                    <span className="text-xs font-medium text-slate-400">
                                        {isUser ? 'You' : 'Rohan'}
                                    </span>
                                    <div
                                        className={`px-4 py-2.5 rounded-2xl max-w-xs text-sm leading-relaxed
                                            ${isUser
                                                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-br-none shadow-md'
                                                : 'bg-slate-700 text-slate-100 rounded-bl-none shadow-md'
                                            }`}
                                    >
                                        {msg.transcript}
                                    </div>
                                </div>
                                {isUser && (
                                    <div className="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center flex-shrink-0 border border-slate-500">
                                        <UserIcon className="w-5 h-5 text-slate-300" />
                                    </div>
                                )}
                            </div>
                        );
                    })
                )}
            </div>
        </section>
    );
}