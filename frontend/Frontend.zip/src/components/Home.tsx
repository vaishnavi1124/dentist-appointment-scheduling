// // // frontend/src/components/Home.tsx
// import VoiceAgent from "./VoiceAgent";
// import Navbar from "./Navbar";
// import Footer from "./Footer";

// export default function Home() {
//     return (
//         <div className="min-h-screen flex flex-col bg-gradient-to-b from-white via-indigo-50 to-white dark:from-slate-900 dark:via-slate-900/60 dark:to-slate-900 text-slate-900 dark:text-slate-100">
//             {/* Safe-area for iOS notches */}
//             <div className="pt-[env(safe-area-inset-top)]" />

//             {/* Navbar */}
//             <header className="sticky top-0 z-50">
//                 <Navbar />
//             </header>

//             {/* Hero + VoiceAgent */}
//             <main id="voice" className="flex-1">
//                 {/* Container with responsive horizontal padding */}
//                 <div className="mx-auto w-full max-w-screen-xl px-4 sm:px-6 lg:px-8">
//                     {/* Headline */}
//                     <section className="pt-8 sm:pt-12 text-center">
//                         {/* First line: BookMyService */}
//                         <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight">
//                             <span className="bg-gradient-to-r from-sky-500 to-indigo-600 bg-clip-text text-transparent">
//                                 Sales Advisor
//                             </span>
//                         </h1>

//                         {/* Second line: Elevate Your AI-Powered Car & Bike Servicing Experience
//                         <h2 className="mt-2 text-xl sm:text-2xl lg:text-3xl font-extrabold tracking-tight">
//                             Elevate Your{" "}
//                             <span className="text-white">
//                                 AI-Powered
//                             </span>{" "}
//                             Your trusted Partner
//                         </h2> */}
// {/* 
//                         <p className="mt-3 sm:mt-4 text-slate-600 dark:text-slate-300 mx-auto max-w-xl text-sm sm:text-base lg:text-lg">
//                             Meet <b>Rohan</b>, BookMyService voice assistant for Car & Bike servicing.
//                         </p> */}

//                         <h3 className="text-xl sm:text-xl lg:text-xl font-extrabold tracking-tight">
//                             Powered by{" "}
            
//     GenIntel Technologies
//                 </h3>

//                         {/* Trust badges */}
//                         <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-sm text-slate-500">
//                             <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 dark:bg-slate-800 px-3 py-1">
//                                 🕑 24×7 assistance
//                             </span>
//                             <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 dark:bg-slate-800 px-3 py-1">
//                                 🌐 Multi-language support
//                             </span>
//                         </div>
//                     </section>

//                     {/* VoiceAgent hero (scales by breakpoint) */}
//                     <section className="mt-2 sm:mt-4 flex justify-center">
//                         <div className="w-full max-w-md sm:max-w-lg md:max-w-xl">
//                             <VoiceAgent />
//                         </div>
//                     </section>
//                 </div>
//             </main>

//             {/* Footer with safe-area bottom */}
//             <footer className="mt-4 sm:mt-2 pb-[env(safe-area-inset-bottom)]">
//                 <Footer />
//             </footer>
//         </div>
//     );
// }


// frontend/src/components/Home.tsx
import VoiceAgent from "./VoiceAgent";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default function Home() {
    return (
        <div className="min-h-screen h-screen flex flex-col bg-gradient-to-br from-[#1A1E2E] via-[#2A3048] to-[#1A1E2E] text-slate-100 font-sans overflow-hidden">
            {/* Safe-area for iOS notches */}
            <div className="pt-[env(safe-area-inset-top)]" />

            {/* Navbar */}
            <header className="sticky top-0 z-50 bg-[#1A1E2E]/80 backdrop-blur-sm shadow-md">
                <Navbar />
            </header>

            {/* Main Content Area */}
            <main id="voice" className="flex-1 flex items-center justify-center p-4">
                {/* Responsive container for Hero and VoiceAgent */}
                <div className="w-full max-w-6xl flex flex-col lg:flex-row items-center justify-around gap-8 lg:gap-16">
                    
                    {/* Headline Section (Left Side on Desktop) */}
                    <section className="text-center lg:text-left">
                        {/* Main Title */}
                        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight bg-gradient-to-r from-blue-400 via-purple-400 to-pink-500 bg-clip-text text-transparent">
                            Sales Advisor
                        </h1>

                        {/* Subtitle */}
                        <h3 className="mt-4 text-lg sm:text-xl font-medium text-slate-300">
                            Powered by{" "}
                            <span className="bg-gradient-to-r from-teal-300 via-cyan-400 to-blue-500 bg-clip-text text-transparent font-semibold">
                                GenIntel Technologies
                            </span>
                        </h3>

                        {/* Trust badges */}
                        <div className="mt-8 flex flex-wrap items-center justify-center lg:justify-start gap-4 text-sm text-slate-300">
                            <span className="inline-flex items-center gap-2 rounded-full bg-slate-800/50 px-4 py-2 border border-slate-700">
                                🕑 24×7 assistance
                            </span>
                            <span className="inline-flex items-center gap-2 rounded-full bg-slate-800/50 px-4 py-2 border border-slate-700">
                                🌐 Multi-language support
                            </span>
                        </div>
                    </section>

                    {/* VoiceAgent Component Section (Right Side on Desktop) */}
                    <section className="w-full flex justify-center lg:w-auto">
                        <div className="w-full max-w-md lg:max-w-lg">
                            <VoiceAgent />
                        </div>
                    </section>
                </div>
            </main>

            {/* Footer */}
            <footer className="w-full text-center p-4 text-slate-500 text-xs pb-[env(safe-area-inset-bottom)]">
                <p>© 2025 GenIntel Technologies. All Rights Reserved.</p>
            </footer>
        </div>
    );
}